[![Build Status](https://travis-ci.org/alibaba/dubbo.svg?branch=master)](https://travis-ci.org/alibaba/dubbo) 
[![Gitter](https://badges.gitter.im/alibaba/dubbo.svg)](https://gitter.im/alibaba/dubbo?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
![](https://img.shields.io/github/license/alibaba/dubbo.svg)
![](https://img.shields.io/maven-central/v/com.alibaba/dubbo.svg)

Pls. visit [dubbo.io](http://dubbo.io) for more information.
